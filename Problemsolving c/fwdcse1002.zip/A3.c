#include<stdio.h>
main()
  {
  char a[5]={'w','e','r','t','y'};
  int b[5]={12,13,23,34,45},i;
  printf("Character Code \t Integer code \n");
  for(i=0;i<5;i++)
      {
      printf("%c \t\t\t  %d \n",a[i],b[i]);
  }
}
