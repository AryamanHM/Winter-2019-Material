#include<stdio.h>
#define PI 3.1415
int main()
{
	int radius;
	float area;
	printf("Enter the radius:");
	scanf("%d",&radius);
	area=PI*radius*radius;
	printf("Area=%.2f",area);
	return 0;
}
