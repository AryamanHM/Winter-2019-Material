#include<stdio.h>
union Data
{
	int aadhar;
	char voterid[30];
};
int main()
{
	union Data data;
	printf("Memory occupied by data:%ld\n",sizeof(data));
	return 0;
}
