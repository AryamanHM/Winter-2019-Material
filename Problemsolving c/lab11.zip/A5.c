#include<stdio.h>
#define area(r)(3.1415*(r)*(r))
int main()
{
	int radius;
	printf("Enter the radius:");
	scanf("%d",&radius);
	printf("Area=%.2f",area(5));
	return 0;
}
